#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "▶ Backend: creating venv and installing packages"
cd backend
python3 -m venv .venv
.venv/bin/pip install -q -r requirements.txt
[ -f .env ] || cp .env.example .env
cd ../frontend
echo "▶ Frontend: installing packages"
npm install --no-audit --no-fund
echo "✔ Done. Now run: ./dev.sh"
