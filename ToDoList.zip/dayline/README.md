# Dayline 🌅
**Plan today. Complete today. Build your streak. Achieve your goals.**

A visual 24-hour task system (fresh every day) plus separate long-term goals.

## Run in GitHub Codespaces
```bash
unzip dayline.zip && cd dayline
./setup.sh      # installs backend + frontend (≈1–2 min)
./dev.sh        # starts API (:8000) and web app (:5173)
```
Open the **Ports** tab, then open port **5173** in the browser. Only 5173 is needed: Vite proxies `/api` and `/uploads` to the backend.

### Database
- `backend/.env` ships with `MONGO_URI=mock`: an in-memory demo database. It works instantly, but **data resets when the backend restarts**.
- For real storage, create a free MongoDB Atlas cluster and paste its URI into `MONGO_URI` (allow access from anywhere in Atlas Network Access, since Codespaces IPs change). Set a long random `JWT_SECRET` too.

### Images
- With `CLOUDINARY_URL` empty, images are saved in `backend/uploads/` (fine for demos).
- To use Cloudinary, set `CLOUDINARY_URL=cloudinary://API_KEY:API_SECRET@CLOUD_NAME` in `backend/.env`. No code change needed.

## Rules implemented
| Case | Behaviour |
|---|---|
| Successful day | At least 1 task and all tasks completed |
| Empty day | Not successful; it breaks the streak. Today never breaks a streak while in progress |
| Unfinished tasks | Stay on their own date; never carried forward |
| Past days | Read-only (browse with the arrows on the Tasks page) |
| Day boundary | Uses the timezone captured at signup (editable in the DB `users.timezone`) |
| Best streak | Stored permanently; only ever increases |
| Tasks completed | Counter; un-completing a task today subtracts 1 |
| Goals | Persistent milestones; progress is computed; independent from the streak |

## Structure
```
backend/app   main.py, routes_auth/tasks/goals/misc.py, stats.py (streak logic), security.py (JWT)
frontend/src  pages/, components/ (TaskCard, ProgressRing, Celebration…), api.js, auth.jsx, data.jsx
```
API docs: open `/docs` on port 8000 (forward it in the Ports tab if you want to explore).
