import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// The dev server proxies /api and /uploads to FastAPI, so in Codespaces
// you only need to open ONE forwarded port (5173).
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    allowedHosts: true,
    proxy: {
      "/api": "http://localhost:8000",
      "/uploads": "http://localhost:8000",
    },
  },
});
