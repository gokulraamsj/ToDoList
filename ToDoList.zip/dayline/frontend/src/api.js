const BASE = "/api";
export const getToken = () => localStorage.getItem("dayline_token");
export const setToken = (t) => (t ? localStorage.setItem("dayline_token", t) : localStorage.removeItem("dayline_token"));

async function req(path, { method = "GET", body, form } = {}) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  let payload;
  if (form) payload = form;
  else if (body) {
    headers["Content-Type"] = "application/json";
    payload = JSON.stringify(body);
  }
  const res = await fetch(BASE + path, { method, headers, body: payload });
  if (res.status === 401 && token) {
    setToken(null);
    window.dispatchEvent(new Event("dayline:logout"));
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    const d = data?.detail;
    throw new Error(typeof d === "string" ? d : Array.isArray(d) ? d.map((x) => x.msg).join(", ") : "Something went wrong");
  }
  return data;
}

export const api = {
  signup: (b) => req("/auth/signup", { method: "POST", body: b }),
  login: (b) => req("/auth/login", { method: "POST", body: b }),
  me: () => req("/auth/me"),
  updateMe: (b) => req("/auth/me", { method: "PUT", body: b }),
  stats: () => req("/stats"),
  upload: (file) => {
    const form = new FormData();
    form.append("file", file);
    return req("/uploads", { method: "POST", form });
  },
  tasks: (date) => req("/tasks" + (date ? `?date=${date}` : "")),
  addTask: (b) => req("/tasks", { method: "POST", body: b }),
  editTask: (id, b) => req(`/tasks/${id}`, { method: "PUT", body: b }),
  toggleTask: (id) => req(`/tasks/${id}/toggle`, { method: "POST" }),
  deleteTask: (id) => req(`/tasks/${id}`, { method: "DELETE" }),
  goals: () => req("/goals"),
  goal: (id) => req(`/goals/${id}`),
  addGoal: (b) => req("/goals", { method: "POST", body: b }),
  editGoal: (id, b) => req(`/goals/${id}`, { method: "PUT", body: b }),
  deleteGoal: (id) => req(`/goals/${id}`, { method: "DELETE" }),
  addMilestone: (id, title) => req(`/goals/${id}/milestones`, { method: "POST", body: { title } }),
  toggleMilestone: (id, mid) => req(`/goals/${id}/milestones/${mid}/toggle`, { method: "POST" }),
  deleteMilestone: (id, mid) => req(`/goals/${id}/milestones/${mid}`, { method: "DELETE" }),
};
