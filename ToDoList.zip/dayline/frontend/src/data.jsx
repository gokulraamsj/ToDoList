import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { api } from "./api";

const Ctx = createContext(null);
export const useData = () => useContext(Ctx);

export function DataProvider({ children }) {
  const [stats, setStats] = useState(null);
  const [celebrating, setCelebrating] = useState(false);
  const ref = useRef(null);

  const applyStats = useCallback((next, checkCelebrate = false) => {
    const wasDone = ref.current?.today.all_done;
    ref.current = next;
    setStats(next);
    if (checkCelebrate && next.today.all_done && !wasDone) setTimeout(() => setCelebrating(true), 350);
  }, []);

  const refresh = useCallback(() => api.stats().then((s) => applyStats(s)), [applyStats]);
  useEffect(() => {
    refresh();
  }, [refresh]);

  return (
    <Ctx.Provider value={{ stats, applyStats, refresh, celebrating, closeCelebration: () => setCelebrating(false) }}>
      {children}
    </Ctx.Provider>
  );
}
