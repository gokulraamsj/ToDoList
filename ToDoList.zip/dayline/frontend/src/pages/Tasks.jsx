import { AnimatePresence, motion } from "framer-motion";
import { ChevronLeft, ChevronRight, Lock, Plus } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import { api } from "../api";
import { useData } from "../data";
import TaskCard from "../components/TaskCard";
import TaskModal from "../components/TaskModal";

const shift = (iso, n) => {
  const d = new Date(iso + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
};

export default function Tasks() {
  const { applyStats } = useData();
  const [day, setDay] = useState(null); // null = today
  const [data, setData] = useState(null);
  const [error, setError] = useState("");
  const [modal, setModal] = useState({ open: false, task: null });

  const load = useCallback(() => api.tasks(day).then(setData).catch((e) => setError(e.message)), [day]);
  useEffect(() => { setData(null); load(); }, [load]);

  if (error) return <p className="text-rose-400">{error}</p>;
  if (!data) return <p className="text-slate-500">Loading…</p>;

  const { tasks, is_today } = data;
  const readOnly = !is_today;
  const done = tasks.filter((t) => t.completed).length;
  const pct = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  const allDone = tasks.length > 0 && done === tasks.length;
  const title = new Date(data.date + "T00:00:00Z").toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric", timeZone: "UTC" });

  const patchTask = (t) => setData((d) => ({ ...d, tasks: d.tasks.map((x) => (x.id === t.id ? t : x)) }));

  const toggle = async (task) => {
    patchTask({ ...task, completed: !task.completed }); // optimistic
    try {
      const res = await api.toggleTask(task.id);
      patchTask(res.task);
      applyStats(res.stats, true);
    } catch (e) { patchTask(task); setError(e.message); }
  };
  const remove = async (task) => {
    const res = await api.deleteTask(task.id);
    setData((d) => ({ ...d, tasks: d.tasks.filter((x) => x.id !== task.id) }));
    applyStats(res.stats);
  };
  const save = async (body) => {
    if (modal.task) {
      const res = await api.editTask(modal.task.id, body);
      patchTask(res.task);
      applyStats(res.stats);
    } else {
      const res = await api.addTask(body);
      setData((d) => ({ ...d, tasks: [...d.tasks, res.task] }));
      applyStats(res.stats);
    }
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-1 -ml-2">
            <button onClick={() => setDay(shift(data.date, -1))} aria-label="Previous day" className="rounded-full p-2 text-slate-400 hover:bg-white/10 hover:text-white"><ChevronLeft size={20} /></button>
            <button disabled={is_today} onClick={() => setDay(shift(data.date, 1))} aria-label="Next day" className="rounded-full p-2 text-slate-400 hover:bg-white/10 hover:text-white disabled:opacity-25 disabled:pointer-events-none"><ChevronRight size={20} /></button>
            {!is_today && <button onClick={() => setDay(null)} className="ml-1 rounded-full bg-white/10 px-3 py-1 text-xs text-white">Back to today</button>}
          </div>
          <h1 className="mt-1 font-display text-3xl sm:text-4xl font-bold text-white">{is_today ? "Today" : title}</h1>
          {is_today && <p className="mt-1 text-slate-400">{title}</p>}
        </div>
        {is_today && <button className="btn-primary" onClick={() => setModal({ open: true, task: null })}><Plus size={18} /> Add task</button>}
      </div>

      {tasks.length > 0 && (
        <div className="mt-6 glass rounded-3xl p-4 sm:p-5">
          <div className="flex items-center justify-between text-sm">
            <span className="font-medium text-white">{done} / {tasks.length} completed</span>
            <span className={allDone ? "text-emerald-400" : "text-slate-400"}>{allDone ? "🎉 Today's tasks completed!" : `${pct}%`}</span>
          </div>
          <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/10">
            <motion.div animate={{ width: `${pct}%` }} transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }} className={`h-full rounded-full ${allDone ? "bg-gradient-to-r from-emerald-300 to-lime-300" : "bg-gradient-to-r from-violet-400 to-cyan-300"}`} />
          </div>
        </div>
      )}

      {readOnly && (
        <p className="mt-5 flex items-center gap-2 text-sm text-slate-500"><Lock size={14} /> This day is closed. Unfinished tasks stay here and are not carried forward.</p>
      )}

      {tasks.length === 0 ? (
        <div className="mt-8 glass rounded-[32px] p-10 sm:p-16 text-center">
          <p className="text-5xl">{is_today ? "🌅" : "🌙"}</p>
          <h2 className="mt-4 font-display text-2xl font-semibold text-white">{is_today ? "A fresh day. No tasks yet." : "No tasks were planned this day."}</h2>
          {is_today && (<>
            <p className="mt-2 text-slate-400">What do you want to get done today?</p>
            <button className="btn-primary mt-6" onClick={() => setModal({ open: true, task: null })}><Plus size={18} /> Add your first task</button>
          </>)}
        </div>
      ) : (
        <div className="mt-6 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {tasks.map((t) => (
              <TaskCard key={t.id} task={t} readOnly={readOnly} onToggle={() => toggle(t)} onEdit={() => setModal({ open: true, task: t })} onDelete={() => remove(t)} />
            ))}
          </AnimatePresence>
        </div>
      )}

      <TaskModal open={modal.open} task={modal.task} onSave={save} onClose={() => setModal({ open: false, task: null })} />
    </div>
  );
}
