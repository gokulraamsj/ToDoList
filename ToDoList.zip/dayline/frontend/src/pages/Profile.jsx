import { LogOut } from "lucide-react";
import { useState } from "react";
import { api } from "../api";
import { useAuth } from "../auth";
import { useData } from "../data";

export default function Profile() {
  const { user, setUser, logout } = useAuth();
  const { stats } = useData();
  const [name, setName] = useState(user.name);
  const [msg, setMsg] = useState("");

  const save = async (e) => {
    e.preventDefault();
    try { setUser(await api.updateMe({ name, timezone: user.timezone })); setMsg("Saved"); }
    catch (err) { setMsg(err.message); }
  };

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Profile</h1>

      <div className="glass rounded-[28px] p-6 flex items-center gap-4">
        <div className="grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-violet-400 to-cyan-300 font-display text-2xl font-extrabold text-ink-950">{user.name[0]?.toUpperCase()}</div>
        <div>
          <p className="font-display text-xl font-semibold text-white">{user.name}</p>
          <p className="text-sm text-slate-400">{user.email}</p>
          <p className="text-xs text-slate-500">Member since {new Date(user.created_at).toLocaleDateString(undefined, { month: "long", year: "numeric" })} · {user.timezone}</p>
        </div>
      </div>

      {stats && (
        <div className="grid grid-cols-3 gap-3 text-center">
          {[["Current streak", stats.current_streak], ["Best streak", stats.best_streak], ["Tasks done", stats.total_completed]].map(([l, v]) => (
            <div key={l} className="glass rounded-2xl py-4"><p className="font-display text-2xl font-bold text-white">{v}</p><p className="text-xs text-slate-500">{l}</p></div>
          ))}
        </div>
      )}

      <form onSubmit={save} className="glass rounded-[28px] p-6 space-y-4">
        <label className="block text-sm text-slate-400">Display name
          <input className="input mt-2" value={name} onChange={(e) => { setName(e.target.value); setMsg(""); }} maxLength={60} required />
        </label>
        <div className="flex items-center gap-3">
          <button className="btn-primary" disabled={!name.trim() || name === user.name}>Save changes</button>
          {msg && <span className="text-sm text-slate-400">{msg}</span>}
        </div>
      </form>

      <button onClick={logout} className="btn-ghost w-full text-rose-300"><LogOut size={16} /> Log out</button>
    </div>
  );
}
