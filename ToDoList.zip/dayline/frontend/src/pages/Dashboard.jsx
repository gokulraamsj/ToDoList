import { motion } from "framer-motion";
import { Flame, Trophy, CheckCheck, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import { useAuth } from "../auth";
import { useData } from "../data";
import GoalBar from "../components/GoalBar";
import ProgressRing from "../components/ProgressRing";
import StreakStrip from "../components/StreakStrip";

function Stat({ icon: Icon, label, value, unit, tint }) {
  return (
    <div className="glass rounded-3xl p-5">
      <Icon size={20} className={tint} />
      <p className="mt-4 font-display text-4xl font-extrabold text-white tabular-nums">{value}<span className="ml-1.5 text-base font-medium text-slate-500">{unit}</span></p>
      <p className="mt-1 text-sm text-slate-400">{label}</p>
    </div>
  );
}

export default function Dashboard() {
  const { user } = useAuth();
  const { stats } = useData();
  const [goals, setGoals] = useState([]);
  useEffect(() => { api.goals().then(setGoals).catch(() => {}); }, []);

  if (!stats) return <p className="text-slate-500">Loading…</p>;
  const t = stats.today;
  const h = new Date().getHours();
  const greet = h < 12 ? "Good morning" : h < 18 ? "Good afternoon" : "Good evening";
  const message = t.total === 0 ? "A clean slate. What do you want to finish today?" : t.all_done ? "Everything you planned is done. 🎉" : `${t.total - t.done} ${t.total - t.done === 1 ? "task" : "tasks"} left to finish today.`;

  return (
    <div className="space-y-5">
      <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">{greet}, {user.name.split(" ")[0]}.</h1>

      <div className="grid gap-5 lg:grid-cols-5">
        <motion.section initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="glass lg:col-span-3 rounded-[32px] p-6 sm:p-8 flex flex-col sm:flex-row items-center gap-8">
          <ProgressRing percent={t.percent} done={t.all_done}>
            <div>
              <p className="font-display text-5xl font-extrabold text-white tabular-nums">{t.done}<span className="text-slate-500"> / {t.total}</span></p>
              <p className="mt-1 text-slate-400">{t.percent}%</p>
            </div>
          </ProgressRing>
          <div className="text-center sm:text-left">
            <p className="text-sm text-slate-400">Today's progress</p>
            <p className="mt-2 font-display text-2xl font-semibold text-white">{message}</p>
            {t.all_done && <p className="mt-2 text-emerald-400">🔥 Your streak continues.</p>}
            <Link to="/tasks" className="btn-primary mt-6">{t.total === 0 ? "Plan today" : "Open today's tasks"} <ArrowRight size={16} /></Link>
          </div>
        </motion.section>

        <div className="lg:col-span-2 grid grid-cols-2 gap-5">
          <Stat icon={Flame} label="Current streak" value={stats.current_streak} unit={stats.current_streak === 1 ? "day" : "days"} tint="text-flame" />
          <Stat icon={Trophy} label="Best streak" value={stats.best_streak} unit={stats.best_streak === 1 ? "day" : "days"} tint="text-amber-300" />
          <div className="col-span-2"><Stat icon={CheckCheck} label="Tasks completed, all time" value={stats.total_completed} tint="text-emerald-400" /></div>
        </div>
      </div>

      <section className="glass rounded-[28px] p-6">
        <div className="mb-4 flex items-baseline justify-between">
          <h2 className="font-display text-lg font-semibold text-white">Last 14 days</h2>
          <p className="text-xs text-slate-500">A green day means every task was completed</p>
        </div>
        <StreakStrip history={stats.history} />
      </section>

      <section className="glass rounded-[28px] p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-white">Your goals</h2>
          <Link to="/goals" className="text-sm text-violet-300 hover:underline">See all</Link>
        </div>
        {goals.length === 0 ? (
          <p className="text-sm text-slate-500">No long-term goals yet. <Link to="/goals" className="text-violet-300 hover:underline">Set your first one.</Link></p>
        ) : (
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {goals.slice(0, 3).map((g) => (
              <Link key={g.id} to={`/goals/${g.id}`} className="block">
                <p className="mb-2 flex justify-between text-sm text-white"><span className="truncate">{g.emoji} {g.title}</span><span className="text-slate-400">{g.percent}%</span></p>
                <GoalBar percent={g.percent} achieved={g.achieved} />
              </Link>
            ))}
          </div>
        )}
      </section>

      <p className="pt-4 text-center font-display text-slate-500">Plan Today. Complete Today. Build Your Streak. Achieve Your Goals.</p>
    </div>
  );
}
