import { motion } from "framer-motion";
import { useState } from "react";
import { useAuth } from "../auth";

export default function AuthPage() {
  const { login, signup } = useAuth();
  const [mode, setMode] = useState("login");
  const [form, setForm] = useState({ name: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setError("");
    try {
      if (mode === "login") await login(form.email, form.password);
      else await signup(form.name, form.email, form.password);
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      <section className="flex flex-col justify-center px-6 sm:px-12 lg:px-16 pt-14 pb-6 lg:py-16">
        <p className="font-display font-bold text-white text-lg">🌅 Dayline</p>
        <h1 className="mt-8 font-display text-5xl sm:text-6xl font-extrabold leading-[1.05] tracking-tight text-white">
          Plan today.<br />Complete today.<br /><span className="text-gradient">Build your streak.</span>
        </h1>
        <p className="mt-6 max-w-md text-lg text-slate-400">Today has its own tasks. Tomorrow starts fresh. Your goals stay with you.</p>

        <div className="relative mt-10 hidden lg:block h-56 max-w-md">
          {[
            { t: "📚 Learn Python OOP", c: "from-violet-500/50 to-cyan-400/30", r: "-rotate-6", x: "left-0", done: true },
            { t: "🏋️ Workout", c: "from-pink-500/40 to-orange-400/30", r: "rotate-3", x: "left-32", done: true },
            { t: "🚀 Ship the project", c: "from-emerald-400/40 to-cyan-400/30", r: "rotate-[10deg]", x: "left-64", done: false },
          ].map((c) => (
            <motion.div key={c.t} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2, type: "spring" }}
              className={`absolute top-4 ${c.x} ${c.r} w-40 overflow-hidden rounded-3xl border border-white/10 bg-ink-800 shadow-2xl`}>
              <div className={`h-24 bg-gradient-to-br ${c.c}`} />
              <div className="p-3 text-xs text-white font-medium">{c.t}
                <div className={`mt-2 text-[10px] ${c.done ? "text-emerald-400" : "text-slate-500"}`}>{c.done ? "✓ Completed" : "○ Complete"}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="flex items-center justify-center px-6 pb-16 lg:py-16">
        <form onSubmit={submit} className="glass w-full max-w-sm rounded-[28px] p-7 shadow-2xl space-y-4">
          <div>
            <h2 className="font-display text-2xl font-semibold text-white">{mode === "login" ? "Welcome back" : "Create your account"}</h2>
            <p className="mt-1 text-sm text-slate-500">{mode === "login" ? "Pick up where today left off." : "Start with a fresh day."}</p>
          </div>
          {mode === "signup" && <input className="input" placeholder="Your name" value={form.name} onChange={set("name")} required maxLength={60} />}
          <input className="input" type="email" placeholder="Email" value={form.email} onChange={set("email")} required autoComplete="email" />
          <input className="input" type="password" placeholder={mode === "signup" ? "Password (8+ characters)" : "Password"} value={form.password} onChange={set("password")} required minLength={mode === "signup" ? 8 : 1} maxLength={72} autoComplete={mode === "login" ? "current-password" : "new-password"} />
          {error && <p className="text-sm text-rose-400">{error}</p>}
          <button className="btn-primary w-full" disabled={busy}>{busy ? "One moment…" : mode === "login" ? "Log in" : "Sign up"}</button>
          <p className="text-center text-sm text-slate-500">
            {mode === "login" ? "New here?" : "Already have an account?"}{" "}
            <button type="button" className="text-violet-300 hover:underline" onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); }}>
              {mode === "login" ? "Create an account" : "Log in"}
            </button>
          </p>
        </form>
      </section>
    </div>
  );
}
