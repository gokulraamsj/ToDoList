import { motion } from "framer-motion";
import { Plus } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../api";
import Art from "../components/Art";
import GoalBar from "../components/GoalBar";
import GoalModal from "../components/GoalModal";

export default function Goals() {
  const [goals, setGoals] = useState(null);
  const [open, setOpen] = useState(false);
  useEffect(() => { api.goals().then(setGoals); }, []);

  const create = async (body) => {
    const g = await api.addGoal(body);
    setGoals((gs) => [...gs, g]);
  };

  if (!goals) return <p className="text-slate-500">Loading…</p>;
  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-white">Goals</h1>
          <p className="mt-1 text-slate-400">What are you ultimately trying to achieve? These never reset.</p>
        </div>
        <button className="btn-primary" onClick={() => setOpen(true)}><Plus size={18} /> New goal</button>
      </div>

      {goals.length === 0 ? (
        <div className="mt-8 glass rounded-[32px] p-10 sm:p-16 text-center">
          <p className="text-5xl">🎯</p>
          <h2 className="mt-4 font-display text-2xl font-semibold text-white">Set a goal that takes longer than a day</h2>
          <p className="mt-2 text-slate-400">Break it into milestones and watch the progress build.</p>
          <button className="btn-primary mt-6" onClick={() => setOpen(true)}><Plus size={18} /> Create your first goal</button>
        </div>
      ) : (
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {goals.map((g) => (
            <motion.div key={g.id} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} whileHover={{ y: -4 }}>
              <Link to={`/goals/${g.id}`} className="group block overflow-hidden rounded-[28px] border border-white/10 bg-white/[0.04] backdrop-blur-xl shadow-xl shadow-black/30">
                <div className="relative aspect-[16/10] overflow-hidden">
                  {g.image_url ? <img src={g.image_url} alt="" loading="lazy" className="h-full w-full object-cover transition duration-700 group-hover:scale-105" /> : <Art seed={g.id} title={g.title} className="h-full w-full" />}
                  <div className="absolute inset-0 bg-gradient-to-t from-ink-950/85 to-transparent" />
                  <span className="absolute bottom-3 left-4 text-3xl">{g.emoji}</span>
                  {g.achieved && <span className="absolute top-3 right-3 rounded-full bg-emerald-400 px-3 py-1 text-xs font-semibold text-ink-950">Achieved</span>}
                </div>
                <div className="p-5">
                  <h3 className="font-display text-lg font-semibold text-white">{g.title}</h3>
                  <div className="mt-4"><GoalBar percent={g.percent} achieved={g.achieved} /></div>
                  <p className="mt-2 flex justify-between text-sm text-slate-400"><span>{g.done} / {g.total} milestones</span><span>{g.percent}%</span></p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      )}
      <GoalModal open={open} onSave={create} onClose={() => setOpen(false)} />
    </div>
  );
}
