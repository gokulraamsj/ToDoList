import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, Check, Pencil, Plus, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { api } from "../api";
import Art from "../components/Art";
import GoalBar from "../components/GoalBar";
import GoalModal from "../components/GoalModal";

export default function GoalDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const [goal, setGoal] = useState(null);
  const [error, setError] = useState("");
  const [text, setText] = useState("");
  const [edit, setEdit] = useState(false);
  const [confirm, setConfirm] = useState(false);

  useEffect(() => { api.goal(id).then(setGoal).catch((e) => setError(e.message)); }, [id]);
  if (error) return <p className="text-rose-400">{error} <Link to="/goals" className="underline">Back to goals</Link></p>;
  if (!goal) return <p className="text-slate-500">Loading…</p>;

  const add = async (e) => {
    e.preventDefault();
    if (!text.trim()) return;
    setGoal(await api.addMilestone(id, text));
    setText("");
  };
  const save = async (body) => setGoal(await api.editGoal(id, body));

  return (
    <div>
      <Link to="/goals" className="mb-4 inline-flex items-center gap-1.5 text-sm text-slate-400 hover:text-white"><ArrowLeft size={16} /> All goals</Link>

      <section className="relative overflow-hidden rounded-[32px] border border-white/10">
        <div className="aspect-[16/9] sm:aspect-[21/9]">
          {goal.image_url ? <img src={goal.image_url} alt="" className="h-full w-full object-cover" /> : <Art seed={goal.id} title={goal.title} className="h-full w-full" />}
        </div>
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/50 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 p-6 sm:p-9">
          <h1 className="font-display text-3xl sm:text-5xl font-extrabold text-white">{goal.emoji} {goal.title}</h1>
          {goal.description && <p className="mt-2 max-w-xl text-slate-300">{goal.description}</p>}
        </div>
        <div className="absolute top-4 right-4 flex gap-2">
          {confirm ? (
            <>
              <button onClick={async () => { await api.deleteGoal(id); nav("/goals"); }} className="rounded-full bg-rose-500 px-4 py-2 text-sm font-medium text-white">Delete goal</button>
              <button onClick={() => setConfirm(false)} className="rounded-full bg-black/60 backdrop-blur px-4 py-2 text-sm text-white">Keep</button>
            </>
          ) : (
            <>
              <button onClick={() => setEdit(true)} aria-label="Edit goal" className="rounded-full bg-black/55 backdrop-blur p-2.5 text-white hover:bg-black/80"><Pencil size={16} /></button>
              <button onClick={() => setConfirm(true)} aria-label="Delete goal" className="rounded-full bg-black/55 backdrop-blur p-2.5 text-white hover:bg-rose-500/80"><Trash2 size={16} /></button>
            </>
          )}
        </div>
      </section>

      <section className="mt-6 glass rounded-[28px] p-6">
        <div className="flex items-end justify-between">
          <p className="font-display text-5xl font-extrabold text-white tabular-nums">{goal.percent}<span className="text-2xl text-slate-500">%</span></p>
          <p className="text-slate-400">{goal.done} / {goal.total} completed</p>
        </div>
        <div className="mt-4"><GoalBar percent={goal.percent} achieved={goal.achieved} height="h-3" /></div>
        {goal.achieved && <p className="mt-4 text-emerald-400">🏆 Goal achieved. Nicely done.</p>}
      </section>

      <section className="mt-6 space-y-2.5">
        <AnimatePresence initial={false}>
          {goal.milestones.map((m) => (
            <motion.div key={m.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, x: -20 }}
              className={`group flex items-center gap-4 rounded-2xl border px-4 py-3.5 transition-colors duration-300 ${m.done ? "border-emerald-400/25 bg-emerald-400/[0.05]" : "border-white/10 bg-white/[0.04]"}`}>
              <button onClick={async () => setGoal(await api.toggleMilestone(id, m.id))} aria-label={m.done ? "Mark as not done" : "Mark as done"} aria-pressed={m.done}
                className={`grid h-7 w-7 shrink-0 place-items-center rounded-full border-2 transition-all duration-300 ${m.done ? "border-emerald-400 bg-emerald-400 text-ink-950" : "border-white/25 hover:border-violet-300"}`}>
                {m.done && <Check size={15} strokeWidth={3} />}
              </button>
              <span className={`flex-1 transition ${m.done ? "text-slate-500 line-through" : "text-slate-100"}`}>{m.title}</span>
              <button onClick={async () => setGoal(await api.deleteMilestone(id, m.id))} aria-label="Delete milestone" className="rounded-full p-1.5 text-slate-500 opacity-100 md:opacity-0 md:group-hover:opacity-100 hover:text-rose-400 transition"><Trash2 size={16} /></button>
            </motion.div>
          ))}
        </AnimatePresence>
        <form onSubmit={add} className="flex gap-2 pt-2">
          <input className="input" placeholder="Add a milestone" value={text} maxLength={160} onChange={(e) => setText(e.target.value)} />
          <button className="btn-ghost shrink-0" aria-label="Add milestone"><Plus size={18} /> Add</button>
        </form>
      </section>

      <GoalModal open={edit} goal={goal} onSave={save} onClose={() => setEdit(false)} />
    </div>
  );
}
