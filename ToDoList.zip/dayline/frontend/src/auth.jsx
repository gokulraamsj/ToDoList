import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { api, getToken, setToken } from "./api";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(!!getToken());

  useEffect(() => {
    if (!getToken()) return;
    api.me().then(setUser).catch(() => setToken(null)).finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    const out = () => setUser(null);
    window.addEventListener("dayline:logout", out);
    return () => window.removeEventListener("dayline:logout", out);
  }, []);

  const accept = ({ token, user }) => {
    setToken(token);
    setUser(user);
  };
  const login = useCallback(async (email, password) => accept(await api.login({ email, password })), []);
  const signup = useCallback(
    async (name, email, password) =>
      accept(await api.signup({ name, email, password, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone })),
    []
  );
  const logout = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  return <Ctx.Provider value={{ user, setUser, loading, login, signup, logout }}>{children}</Ctx.Provider>;
}
