import { Navigate, Outlet, Route, Routes } from "react-router-dom";
import { useAuth } from "./auth";
import { DataProvider } from "./data";
import Backdrop from "./components/Backdrop";
import Nav from "./components/Nav";
import Celebration from "./components/Celebration";
import AuthPage from "./pages/AuthPage";
import Dashboard from "./pages/Dashboard";
import Tasks from "./pages/Tasks";
import Goals from "./pages/Goals";
import GoalDetail from "./pages/GoalDetail";
import Profile from "./pages/Profile";

function Shell() {
  const { user, loading } = useAuth();
  if (loading) return <div className="min-h-screen grid place-items-center text-slate-500">Loading…</div>;
  if (!user) return <Navigate to="/auth" replace />;
  return (
    <DataProvider>
      <Nav />
      <main className="mx-auto max-w-6xl px-4 sm:px-6 pt-8 md:pt-28 pb-32 md:pb-16">
        <Outlet />
      </main>
      <Celebration />
    </DataProvider>
  );
}

export default function App() {
  const { user } = useAuth();
  return (
    <>
      <Backdrop />
      <Routes>
        <Route path="/auth" element={user ? <Navigate to="/" replace /> : <AuthPage />} />
        <Route element={<Shell />}>
          <Route index element={<Dashboard />} />
          <Route path="tasks" element={<Tasks />} />
          <Route path="goals" element={<Goals />} />
          <Route path="goals/:id" element={<GoalDetail />} />
          <Route path="profile" element={<Profile />} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </>
  );
}
