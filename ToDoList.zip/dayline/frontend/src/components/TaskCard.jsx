import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown, Circle, Pencil, Trash2 } from "lucide-react";
import { useState } from "react";
import Art from "./Art";

export default function TaskCard({ task, readOnly, onToggle, onEdit, onDelete }) {
  const [open, setOpen] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const done = task.completed;

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, scale: 0.94 }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      whileHover={readOnly ? undefined : { y: -4 }}
      className={`group relative flex flex-col overflow-hidden rounded-[28px] border transition-colors duration-500 ${
        done ? "border-emerald-400/30 bg-emerald-400/[0.05]" : "border-white/10 bg-white/[0.04]"
      } backdrop-blur-xl shadow-xl shadow-black/30`}
    >
      {/* Image: the star of the card */}
      <div className="relative aspect-[4/3] overflow-hidden">
        {task.image_url ? (
          <img src={task.image_url} alt="" loading="lazy" className={`h-full w-full object-cover transition duration-700 group-hover:scale-105 ${done ? "saturate-50 brightness-75" : ""}`} />
        ) : (
          <Art seed={task.id} title={task.title} className={`h-full w-full transition duration-700 ${done ? "saturate-50 brightness-75" : ""}`} />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950/80 via-transparent to-transparent" />
        <AnimatePresence>
          {done && (
            <motion.div initial={{ scale: 0, rotate: -40 }} animate={{ scale: 1, rotate: 0 }} exit={{ scale: 0 }} transition={{ type: "spring", stiffness: 400, damping: 18 }}
              className="absolute top-3 right-3 grid h-11 w-11 place-items-center rounded-full bg-emerald-400 text-ink-950 shadow-lg shadow-emerald-500/40">
              <Check size={22} strokeWidth={3} />
            </motion.div>
          )}
        </AnimatePresence>
        {!readOnly && (
          <div className="absolute top-3 left-3 flex gap-1.5 opacity-100 md:opacity-0 md:group-hover:opacity-100 focus-within:opacity-100 transition">
            {confirming ? (
              <>
                <button onClick={onDelete} className="rounded-full bg-rose-500 px-3 py-1.5 text-xs font-medium text-white">Delete</button>
                <button onClick={() => setConfirming(false)} className="rounded-full bg-black/60 backdrop-blur px-3 py-1.5 text-xs text-white">Keep</button>
              </>
            ) : (
              <>
                <button onClick={onEdit} aria-label="Edit task" className="rounded-full bg-black/55 backdrop-blur p-2 text-white hover:bg-black/80"><Pencil size={14} /></button>
                <button onClick={() => setConfirming(true)} aria-label="Delete task" className="rounded-full bg-black/55 backdrop-blur p-2 text-white hover:bg-rose-500/80"><Trash2 size={14} /></button>
              </>
            )}
          </div>
        )}
      </div>

      <div className="flex flex-1 flex-col p-5">
        <h3 className={`font-display text-lg font-semibold leading-snug transition-colors ${done ? "text-slate-400 line-through decoration-emerald-400/60" : "text-white"}`}>{task.title}</h3>

        {task.description && (
          <>
            <button onClick={() => setOpen((o) => !o)} aria-expanded={open} className="mt-3 flex w-fit items-center gap-1.5 text-sm text-slate-400 hover:text-white transition">
              <motion.span animate={{ rotate: open ? 180 : 0 }}><ChevronDown size={16} /></motion.span>
              {open ? "Hide details" : "View details"}
            </button>
            <AnimatePresence initial={false}>
              {open && (
                <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: "auto", opacity: 1 }} exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.28, ease: "easeOut" }} className="overflow-hidden">
                  <p className="whitespace-pre-wrap pt-3 text-sm leading-relaxed text-slate-400">{task.description}</p>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}

        <div className="mt-auto flex justify-end pt-5">
          {readOnly ? (
            <span className={`text-sm ${done ? "text-emerald-400" : "text-slate-500"}`}>{done ? "Completed" : "Not completed"}</span>
          ) : (
            <motion.button
              whileTap={{ scale: 0.94 }} onClick={onToggle}
              className={`flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors duration-300 ${
                done ? "bg-emerald-400 text-ink-950" : "border border-white/15 text-slate-200 hover:bg-white/10"
              }`}
            >
              {done ? <Check size={16} strokeWidth={3} /> : <Circle size={16} />}
              {done ? "Completed" : "Complete"}
            </motion.button>
          )}
        </div>
      </div>
    </motion.article>
  );
}
