import { useState } from "react";
import Modal from "./Modal";
import ImagePicker from "./ImagePicker";
import useImageField from "./useImageField";

function Form({ goal, onSave, onClose }) {
  const [title, setTitle] = useState(goal?.title || "");
  const [emoji, setEmoji] = useState(goal?.emoji || "🎯");
  const [description, setDescription] = useState(goal?.description || "");
  const [milestones, setMilestones] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const img = useImageField(goal?.image_url);

  const submit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return setError("Give your goal a title");
    setSaving(true);
    try {
      await onSave({ title, emoji, description, image_url: await img.resolve(), milestones: milestones.split("\n").map((s) => s.trim()).filter(Boolean) });
      onClose();
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <ImagePicker preview={img.preview} onPick={img.pick} onClear={img.clear} />
      <div className="flex gap-3">
        <input className="input !w-16 text-center text-lg" value={emoji} maxLength={4} onChange={(e) => setEmoji(e.target.value)} aria-label="Emoji" />
        <input className="input" placeholder="What are you ultimately trying to achieve?" value={title} maxLength={120} onChange={(e) => setTitle(e.target.value)} autoFocus />
      </div>
      <textarea className="input min-h-20 resize-y" placeholder="Why does this matter to you? (optional)" value={description} onChange={(e) => setDescription(e.target.value)} />
      {!goal && (
        <textarea className="input min-h-28 resize-y" placeholder={"Milestones, one per line\nLearn Python\nLearn Machine Learning"} value={milestones} onChange={(e) => setMilestones(e.target.value)} />
      )}
      {error && <p className="text-sm text-rose-400">{error}</p>}
      <div className="flex justify-end gap-2">
        <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn-primary" disabled={saving}>{saving ? "Saving…" : goal ? "Save changes" : "Create goal"}</button>
      </div>
    </form>
  );
}

export default function GoalModal({ open, goal, onSave, onClose }) {
  return (
    <Modal open={open} onClose={onClose} title={goal ? "Edit goal" : "New long-term goal"}>
      {open && <Form key={goal?.id || "new"} goal={goal} onSave={onSave} onClose={onClose} />}
    </Modal>
  );
}
