export default function Backdrop() {
  return (
    <div aria-hidden className="fixed inset-0 -z-10 overflow-hidden bg-ink-950">
      <div className="absolute -top-40 -left-32 h-[34rem] w-[34rem] rounded-full bg-violet-600/25 blur-[120px] animate-drift" />
      <div className="absolute top-1/3 -right-40 h-[32rem] w-[32rem] rounded-full bg-cyan-500/15 blur-[130px] animate-drift [animation-delay:-6s]" />
      <div className="absolute -bottom-48 left-1/4 h-[30rem] w-[30rem] rounded-full bg-fuchsia-600/10 blur-[130px] animate-drift [animation-delay:-12s]" />
      <div className="absolute inset-0 bg-grid" />
    </div>
  );
}
