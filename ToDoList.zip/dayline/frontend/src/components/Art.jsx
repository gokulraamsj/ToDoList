// Generated artwork used when a task/goal has no image, so cards always look rich.
const PAIRS = [["#8b7bff", "#4cc9f0"], ["#f472b6", "#fb923c"], ["#34d399", "#22d3ee"], ["#a78bfa", "#f472b6"], ["#fbbf24", "#f87171"], ["#60a5fa", "#a78bfa"]];
const hash = (s) => [...s].reduce((h, ch) => (h * 31 + ch.charCodeAt(0)) >>> 0, 7);

export default function Art({ seed = "", title = "", className = "" }) {
  const [a, b] = PAIRS[hash(seed + title) % PAIRS.length];
  const emoji = title.match(/\p{Extended_Pictographic}/u)?.[0];
  const glyph = emoji || title.trim()[0]?.toUpperCase() || "✦";
  return (
    <div className={`relative overflow-hidden ${className}`} style={{ background: `linear-gradient(135deg, ${a}66, ${b}33), #0b0d14` }}>
      <div className="absolute -top-10 -right-10 h-48 w-48 rounded-full blur-2xl" style={{ background: `${b}55` }} />
      <div className="absolute -bottom-16 -left-10 h-56 w-56 rounded-full blur-3xl" style={{ background: `${a}44` }} />
      <span className="absolute inset-0 grid place-items-center font-display font-extrabold text-white/80 text-7xl drop-shadow-lg">{glyph}</span>
    </div>
  );
}
