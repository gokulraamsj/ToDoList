import { useState } from "react";
import Modal from "./Modal";
import ImagePicker from "./ImagePicker";
import useImageField from "./useImageField";

function Form({ task, onSave, onClose }) {
  const [title, setTitle] = useState(task?.title || "");
  const [description, setDescription] = useState(task?.description || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const img = useImageField(task?.image_url);

  const submit = async (e) => {
    e.preventDefault();
    if (!title.trim()) return setError("Give your task a title");
    setSaving(true);
    setError("");
    try {
      await onSave({ title, description, image_url: await img.resolve() });
      onClose();
    } catch (err) {
      setError(err.message);
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4">
      <ImagePicker preview={img.preview} onPick={img.pick} onClear={img.clear} />
      <input className="input" placeholder="What do you want to finish today? e.g. 📚 Learn Python OOP" value={title} maxLength={120} onChange={(e) => setTitle(e.target.value)} autoFocus />
      <textarea className="input min-h-28 resize-y" placeholder="Details (optional). Shown when the card is expanded." value={description} maxLength={2000} onChange={(e) => setDescription(e.target.value)} />
      {error && <p className="text-sm text-rose-400">{error}</p>}
      <div className="flex justify-end gap-2 pt-1">
        <button type="button" className="btn-ghost" onClick={onClose}>Cancel</button>
        <button className="btn-primary" disabled={saving}>{saving ? "Saving…" : task ? "Save changes" : "Add task"}</button>
      </div>
    </form>
  );
}

export default function TaskModal({ open, task, onSave, onClose }) {
  return (
    <Modal open={open} onClose={onClose} title={task ? "Edit task" : "Add a task for today"}>
      {open && <Form key={task?.id || "new"} task={task} onSave={onSave} onClose={onClose} />}
    </Modal>
  );
}
