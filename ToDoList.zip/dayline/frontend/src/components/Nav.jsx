import { NavLink } from "react-router-dom";
import { motion } from "framer-motion";
import { LayoutGrid, ListChecks, Target, User, Sunrise } from "lucide-react";

const items = [
  { to: "/", label: "Dashboard", icon: LayoutGrid, end: true },
  { to: "/tasks", label: "Tasks", icon: ListChecks },
  { to: "/goals", label: "Goals", icon: Target },
  { to: "/profile", label: "Profile", icon: User },
];

export default function Nav() {
  return (
    <>
      {/* desktop: floating pill */}
      <header className="hidden md:flex fixed top-5 inset-x-0 z-40 justify-center pointer-events-none">
        <nav className="pointer-events-auto glass rounded-full pl-5 pr-2 py-2 flex items-center gap-4 shadow-2xl shadow-black/40">
          <span className="flex items-center gap-2 font-display font-bold text-white tracking-tight">
            <Sunrise size={18} className="text-amber-300" /> Dayline
          </span>
          <div className="flex gap-1">
            {items.map(({ to, label, end }) => (
              <NavLink key={to} to={to} end={end} className="relative px-4 py-2 text-sm rounded-full">
                {({ isActive }) => (
                  <>
                    {isActive && (
                      <motion.span layoutId="nav-pill" className="absolute inset-0 rounded-full bg-white/10 border border-white/10" transition={{ type: "spring", stiffness: 400, damping: 32 }} />
                    )}
                    <span className={`relative ${isActive ? "text-white" : "text-slate-400 hover:text-slate-200"}`}>{label}</span>
                  </>
                )}
              </NavLink>
            ))}
          </div>
        </nav>
      </header>

      {/* mobile: bottom tab bar */}
      <nav className="md:hidden fixed bottom-3 inset-x-3 z-40 glass rounded-3xl bg-ink-900/80 flex justify-around p-1.5 shadow-2xl shadow-black/60">
        {items.map(({ to, label, icon: Icon, end }) => (
          <NavLink key={to} to={to} end={end} className={({ isActive }) => `flex flex-col items-center gap-0.5 rounded-2xl px-4 py-2 text-[11px] transition ${isActive ? "bg-white/10 text-white" : "text-slate-500"}`}>
            <Icon size={20} />
            {label}
          </NavLink>
        ))}
      </nav>
    </>
  );
}
