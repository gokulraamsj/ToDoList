import { motion } from "framer-motion";

export default function GoalBar({ percent, achieved, height = "h-2" }) {
  return (
    <div className={`w-full ${height} overflow-hidden rounded-full bg-white/10`}>
      <motion.div initial={{ width: 0 }} animate={{ width: `${percent}%` }} transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
        className={`h-full rounded-full ${achieved ? "bg-gradient-to-r from-emerald-300 to-lime-300" : "bg-gradient-to-r from-violet-400 to-cyan-300"}`} />
    </div>
  );
}
