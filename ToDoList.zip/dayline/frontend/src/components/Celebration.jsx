import confetti from "canvas-confetti";
import { AnimatePresence, motion } from "framer-motion";
import { useEffect } from "react";
import { useData } from "../data";

export default function Celebration() {
  const { celebrating, closeCelebration, stats } = useData();

  useEffect(() => {
    if (!celebrating) return;
    const colors = ["#8b7bff", "#4cc9f0", "#34d399", "#fbbf24"];
    confetti({ particleCount: 90, spread: 80, origin: { y: 0.65 }, colors });
    setTimeout(() => confetti({ particleCount: 60, angle: 60, spread: 60, origin: { x: 0, y: 0.7 }, colors }), 200);
    setTimeout(() => confetti({ particleCount: 60, angle: 120, spread: 60, origin: { x: 1, y: 0.7 }, colors }), 200);
    const t = setTimeout(closeCelebration, 5500);
    return () => clearTimeout(t);
  }, [celebrating, closeCelebration]);

  return (
    <AnimatePresence>
      {celebrating && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={closeCelebration}
          className="fixed inset-0 z-[60] grid place-items-center bg-black/55 backdrop-blur-sm p-4 cursor-pointer">
          <motion.div initial={{ scale: 0.85, y: 20 }} animate={{ scale: 1, y: 0 }} exit={{ scale: 0.9, opacity: 0 }} transition={{ type: "spring", damping: 18 }}
            className="glass bg-ink-900/90 rounded-[32px] px-10 py-9 text-center max-w-sm shadow-2xl shadow-emerald-500/10">
            <div className="text-5xl">🎉</div>
            <h2 className="mt-4 font-display text-2xl font-bold text-white">Today's tasks completed!</h2>
            <p className="mt-3 text-slate-300">🔥 Your streak continues.</p>
            <p className="mt-1 font-display text-4xl font-extrabold text-gradient">{stats?.current_streak} {stats?.current_streak === 1 ? "day" : "days"}</p>
            <p className="mt-5 text-xs text-slate-500">Tap anywhere to close</p>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
