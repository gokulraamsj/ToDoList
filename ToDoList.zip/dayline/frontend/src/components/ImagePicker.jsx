import { ImagePlus, Trash2 } from "lucide-react";
import { useRef } from "react";

export default function ImagePicker({ preview, onPick, onClear }) {
  const input = useRef(null);
  const handle = (file) => file && file.type.startsWith("image/") && onPick(file);
  return (
    <div>
      <input ref={input} type="file" accept="image/*" hidden onChange={(e) => handle(e.target.files[0])} />
      {preview ? (
        <div className="relative overflow-hidden rounded-2xl border border-white/10 aspect-[16/9]">
          <img src={preview} alt="Preview" className="h-full w-full object-cover" />
          <div className="absolute top-2 right-2 flex gap-2">
            <button type="button" onClick={() => input.current.click()} className="rounded-full bg-black/60 backdrop-blur px-3 py-1.5 text-xs text-white hover:bg-black/80">Change</button>
            <button type="button" onClick={onClear} aria-label="Remove image" className="rounded-full bg-black/60 backdrop-blur p-2 text-white hover:bg-red-500/80"><Trash2 size={14} /></button>
          </div>
        </div>
      ) : (
        <button
          type="button"
          onClick={() => input.current.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => { e.preventDefault(); handle(e.dataTransfer.files[0]); }}
          className="w-full aspect-[16/9] rounded-2xl border border-dashed border-white/20 bg-white/[0.03] hover:bg-white/[0.06] hover:border-violet-400/50 transition grid place-items-center text-slate-400"
        >
          <span className="flex flex-col items-center gap-2 text-sm">
            <ImagePlus size={26} />
            Add a cover image
            <span className="text-xs text-slate-500">Click or drop a file</span>
          </span>
        </button>
      )}
    </div>
  );
}
