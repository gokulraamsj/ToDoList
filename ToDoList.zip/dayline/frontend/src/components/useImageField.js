import { useEffect, useState } from "react";
import { api } from "../api";

// Handles: existing url, newly picked file (preview), removal, and upload-on-save.
export default function useImageField(initialUrl) {
  const [url, setUrl] = useState(initialUrl || null);
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(initialUrl || null);

  useEffect(() => () => preview?.startsWith("blob:") && URL.revokeObjectURL(preview), [preview]);

  return {
    preview,
    pick: (f) => { setFile(f); setPreview(URL.createObjectURL(f)); },
    clear: () => { setFile(null); setUrl(null); setPreview(null); },
    resolve: async () => (file ? (await api.upload(file)).url : url),
  };
}
