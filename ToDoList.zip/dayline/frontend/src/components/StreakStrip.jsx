const styles = {
  success: "bg-gradient-to-br from-emerald-300 to-lime-300 border-transparent",
  missed: "bg-rose-400/20 border-rose-400/30",
  pending: "bg-violet-400/20 border-violet-400/40",
  empty: "bg-white/[0.04] border-white/10",
};
const label = { success: "All tasks completed", missed: "Tasks left unfinished", pending: "In progress", empty: "No tasks" };

export default function StreakStrip({ history = [] }) {
  return (
    <div className="flex gap-1.5 sm:gap-2">
      {history.map((d) => (
        <div key={d.date} className="flex-1 text-center">
          <div title={`${d.date}: ${label[d.status]}${d.total ? ` (${d.done}/${d.total})` : ""}`}
            className={`aspect-square rounded-lg sm:rounded-xl border ${styles[d.status]} ${d.is_today ? "ring-2 ring-white/60 ring-offset-2 ring-offset-ink-950" : ""}`} />
          <span className="mt-1.5 block text-[10px] text-slate-500">{new Date(d.date + "T00:00:00Z").toLocaleDateString(undefined, { weekday: "narrow", timeZone: "UTC" })}</span>
        </div>
      ))}
    </div>
  );
}
