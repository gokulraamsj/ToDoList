/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        display: ["Sora", "system-ui", "sans-serif"],
        sans: ["Inter", "system-ui", "sans-serif"],
      },
      colors: {
        ink: { 950: "#07080d", 900: "#0b0d14", 800: "#11141d", 700: "#1a1e2a" },
        flame: "#ff8a3d",
        mint: "#4ade80",
      },
      keyframes: {
        drift: {
          "0%,100%": { transform: "translate3d(0,0,0) scale(1)" },
          "50%": { transform: "translate3d(40px,-30px,0) scale(1.12)" },
        },
        pop: {
          "0%": { transform: "scale(.4)", opacity: 0 },
          "60%": { transform: "scale(1.15)", opacity: 1 },
          "100%": { transform: "scale(1)" },
        },
      },
      animation: { drift: "drift 18s ease-in-out infinite", pop: "pop .45s cubic-bezier(.22,1,.36,1)" },
    },
  },
  plugins: [],
};
