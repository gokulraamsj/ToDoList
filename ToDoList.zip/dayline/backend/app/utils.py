from datetime import date, datetime, timezone
from zoneinfo import ZoneInfo

from bson import ObjectId
from fastapi import HTTPException


def now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def valid_tz(name: str | None) -> str:
    try:
        ZoneInfo(name or "UTC")
        return name or "UTC"
    except Exception:
        return "UTC"


def today_for(user: dict) -> date:
    return datetime.now(ZoneInfo(valid_tz(user.get("timezone")))).date()


def parse_date(s: str) -> date:
    try:
        return date.fromisoformat(s)
    except ValueError:
        raise HTTPException(400, "Date must be YYYY-MM-DD")


def oid(s: str) -> ObjectId:
    try:
        return ObjectId(s)
    except Exception:
        raise HTTPException(404, "Not found")
