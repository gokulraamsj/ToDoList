"""Streak + progress rules (the heart of the app).

A day is SUCCESSFUL  <=> it has at least one task AND every task is completed.
An EMPTY day is NOT successful (it breaks a streak), but today never breaks a
streak while it is still in progress.
"""
from datetime import timedelta

from .db import db
from .utils import today_for


async def compute_stats(user_id):
    user = await db.users.find_one({"_id": user_id})
    today = today_for(user)

    rows = await db.tasks.find({"user_id": user_id}, {"date": 1, "completed": 1}).to_list(None)
    per_day: dict[str, list[int]] = {}
    for r in rows:
        d = per_day.setdefault(r["date"], [0, 0])
        d[0] += 1
        d[1] += 1 if r["completed"] else 0

    success = {k for k, (t, c) in per_day.items() if t > 0 and t == c}

    # best streak from full history
    best_hist, run, prev = 0, 0, None
    for k in sorted(success):
        day = today.fromisoformat(k)
        run = run + 1 if prev and (day - prev).days == 1 else 1
        best_hist = max(best_hist, run)
        prev = day

    # current streak: walk back from today (if done) else from yesterday
    cursor = today if today.isoformat() in success else today - timedelta(days=1)
    current = 0
    while cursor.isoformat() in success:
        current += 1
        cursor -= timedelta(days=1)

    best = max(user.get("best_streak", 0), best_hist, current)
    if best != user.get("best_streak", 0):
        await db.users.update_one({"_id": user_id}, {"$set": {"best_streak": best}})

    t, c = per_day.get(today.isoformat(), [0, 0])
    history = []
    for i in range(13, -1, -1):
        d = today - timedelta(days=i)
        dt, dc = per_day.get(d.isoformat(), [0, 0])
        if dt == 0:
            status = "empty"
        elif dt == dc:
            status = "success"
        else:
            status = "pending" if d == today else "missed"
        history.append({"date": d.isoformat(), "total": dt, "done": dc, "status": status, "is_today": d == today})

    return {
        "today": {
            "date": today.isoformat(),
            "total": t,
            "done": c,
            "percent": round(c / t * 100) if t else 0,
            "all_done": t > 0 and t == c,
        },
        "current_streak": current,
        "best_streak": best,
        "total_completed": max(0, user.get("total_completed", 0)),
        "history": history,
    }
