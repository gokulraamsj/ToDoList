import os
import uuid
from pathlib import Path

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool

from .security import current_user
from .stats import compute_stats

router = APIRouter(tags=["misc"])
UPLOAD_DIR = Path(__file__).resolve().parent.parent / "uploads"
UPLOAD_DIR.mkdir(exist_ok=True)
MAX_BYTES = 8 * 1024 * 1024
EXT = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp", "image/gif": ".gif"}


@router.get("/health")
async def health():
    return {"ok": True}


@router.get("/stats")
async def stats(user=Depends(current_user)):
    return await compute_stats(user["_id"])


@router.post("/uploads")
async def upload(file: UploadFile = File(...), user=Depends(current_user)):
    if file.content_type not in EXT:
        raise HTTPException(400, "Please upload a JPG, PNG, WEBP or GIF image")
    data = await file.read()
    if len(data) > MAX_BYTES:
        raise HTTPException(413, "Image is too large (max 8 MB)")

    if os.getenv("CLOUDINARY_URL"):
        import cloudinary.uploader

        res = await run_in_threadpool(lambda: cloudinary.uploader.upload(data, folder="dayline"))
        return {"url": res["secure_url"]}

    name = uuid.uuid4().hex + EXT[file.content_type]
    (UPLOAD_DIR / name).write_bytes(data)
    return {"url": f"/uploads/{name}"}
