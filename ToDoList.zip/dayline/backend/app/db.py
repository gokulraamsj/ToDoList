import os
from dotenv import load_dotenv

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mock")
DB_NAME = os.getenv("DB_NAME", "dayline")

if MONGO_URI.startswith("mock"):
    from mongomock_motor import AsyncMongoMockClient

    client = AsyncMongoMockClient()
    print("⚠  Using in-memory mock database. Data resets on restart. Set MONGO_URI for MongoDB.")
else:
    from motor.motor_asyncio import AsyncIOMotorClient

    client = AsyncIOMotorClient(MONGO_URI)

db = client[DB_NAME]
