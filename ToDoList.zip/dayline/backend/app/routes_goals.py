import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .db import db
from .security import current_user
from .utils import now, oid

router = APIRouter(prefix="/goals", tags=["goals"])


class GoalIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    emoji: str = Field(default="🎯", max_length=8)
    description: str = Field(default="", max_length=1000)
    image_url: str | None = None
    milestones: list[str] = Field(default_factory=list, max_length=100)


class MilestoneIn(BaseModel):
    title: str = Field(min_length=1, max_length=160)


def ser(g: dict) -> dict:
    ms = g.get("milestones", [])
    done = sum(1 for m in ms if m["done"])
    return {
        "id": str(g["_id"]),
        "title": g["title"],
        "emoji": g.get("emoji", "🎯"),
        "description": g.get("description", ""),
        "image_url": g.get("image_url"),
        "milestones": ms,
        "done": done,
        "total": len(ms),
        "percent": round(done / len(ms) * 100) if ms else 0,
        "achieved": bool(ms) and done == len(ms),
    }


async def own_goal(goal_id: str, user: dict) -> dict:
    g = await db.goals.find_one({"_id": oid(goal_id), "user_id": user["_id"]})
    if not g:
        raise HTTPException(404, "Goal not found")
    return g


async def save_milestones(g: dict) -> dict:
    await db.goals.update_one({"_id": g["_id"]}, {"$set": {"milestones": g["milestones"]}})
    return ser(g)


def new_ms(title: str) -> dict:
    return {"id": uuid.uuid4().hex[:10], "title": title.strip(), "done": False}


@router.get("")
async def list_goals(user=Depends(current_user)):
    docs = await db.goals.find({"user_id": user["_id"]}).sort("created_at", 1).to_list(None)
    return [ser(g) for g in docs]


@router.post("")
async def create_goal(body: GoalIn, user=Depends(current_user)):
    doc = {
        "user_id": user["_id"],
        "title": body.title.strip(),
        "emoji": body.emoji or "🎯",
        "description": body.description.strip(),
        "image_url": body.image_url,
        "milestones": [new_ms(m) for m in body.milestones if m.strip()],
        "created_at": now(),
    }
    res = await db.goals.insert_one(doc)
    doc["_id"] = res.inserted_id
    return ser(doc)


@router.get("/{goal_id}")
async def get_goal(goal_id: str, user=Depends(current_user)):
    return ser(await own_goal(goal_id, user))


@router.put("/{goal_id}")
async def update_goal(goal_id: str, body: GoalIn, user=Depends(current_user)):
    g = await own_goal(goal_id, user)
    patch = {
        "title": body.title.strip(),
        "emoji": body.emoji or "🎯",
        "description": body.description.strip(),
        "image_url": body.image_url,
    }
    await db.goals.update_one({"_id": g["_id"]}, {"$set": patch})
    g.update(patch)
    return ser(g)


@router.delete("/{goal_id}")
async def delete_goal(goal_id: str, user=Depends(current_user)):
    g = await own_goal(goal_id, user)
    await db.goals.delete_one({"_id": g["_id"]})
    return {"ok": True}


@router.post("/{goal_id}/milestones")
async def add_milestone(goal_id: str, body: MilestoneIn, user=Depends(current_user)):
    g = await own_goal(goal_id, user)
    g["milestones"].append(new_ms(body.title))
    return await save_milestones(g)


@router.post("/{goal_id}/milestones/{mid}/toggle")
async def toggle_milestone(goal_id: str, mid: str, user=Depends(current_user)):
    g = await own_goal(goal_id, user)
    for m in g["milestones"]:
        if m["id"] == mid:
            m["done"] = not m["done"]
            return await save_milestones(g)
    raise HTTPException(404, "Milestone not found")


@router.delete("/{goal_id}/milestones/{mid}")
async def delete_milestone(goal_id: str, mid: str, user=Depends(current_user)):
    g = await own_goal(goal_id, user)
    g["milestones"] = [m for m in g["milestones"] if m["id"] != mid]
    return await save_milestones(g)
