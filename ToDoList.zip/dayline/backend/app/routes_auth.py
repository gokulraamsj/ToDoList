import re

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .db import db
from .security import check_pw, current_user, hash_pw, make_token
from .utils import now, valid_tz

router = APIRouter(prefix="/auth", tags=["auth"])
EMAIL = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class SignupIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    email: str
    password: str = Field(min_length=8, max_length=72)
    timezone: str | None = None


class LoginIn(BaseModel):
    email: str
    password: str = Field(max_length=72)


class ProfileIn(BaseModel):
    name: str = Field(min_length=1, max_length=60)
    timezone: str | None = None


def public(u: dict) -> dict:
    return {
        "id": str(u["_id"]),
        "name": u["name"],
        "email": u["email"],
        "timezone": u.get("timezone", "UTC"),
        "created_at": u["created_at"].isoformat() + "Z",
    }


@router.post("/signup")
async def signup(body: SignupIn):
    email = body.email.strip().lower()
    if not EMAIL.match(email):
        raise HTTPException(400, "Enter a valid email address")
    if await db.users.find_one({"email": email}):
        raise HTTPException(409, "An account with this email already exists")
    doc = {
        "name": body.name.strip(),
        "email": email,
        "password": hash_pw(body.password),
        "timezone": valid_tz(body.timezone),
        "best_streak": 0,
        "total_completed": 0,
        "created_at": now(),
    }
    res = await db.users.insert_one(doc)
    doc["_id"] = res.inserted_id
    return {"token": make_token(str(res.inserted_id)), "user": public(doc)}


@router.post("/login")
async def login(body: LoginIn):
    user = await db.users.find_one({"email": body.email.strip().lower()})
    if not user or not check_pw(body.password, user["password"]):
        raise HTTPException(401, "Wrong email or password")
    return {"token": make_token(str(user["_id"])), "user": public(user)}


@router.get("/me")
async def me(user=Depends(current_user)):
    return public(user)


@router.put("/me")
async def update_me(body: ProfileIn, user=Depends(current_user)):
    patch = {"name": body.name.strip()}
    if body.timezone:
        patch["timezone"] = valid_tz(body.timezone)
    await db.users.update_one({"_id": user["_id"]}, {"$set": patch})
    user.update(patch)
    return public(user)
