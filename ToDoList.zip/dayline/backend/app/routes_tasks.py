from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from .db import db
from .security import current_user
from .stats import compute_stats
from .utils import now, oid, parse_date, today_for

router = APIRouter(prefix="/tasks", tags=["tasks"])


class TaskIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=2000)
    image_url: str | None = None


def ser(t: dict) -> dict:
    return {
        "id": str(t["_id"]),
        "date": t["date"],
        "title": t["title"],
        "description": t.get("description", ""),
        "image_url": t.get("image_url"),
        "completed": t["completed"],
    }


async def own_task_today(task_id: str, user: dict) -> dict:
    t = await db.tasks.find_one({"_id": oid(task_id), "user_id": user["_id"]})
    if not t:
        raise HTTPException(404, "Task not found")
    if t["date"] != today_for(user).isoformat():
        raise HTTPException(403, "That day is closed. Past days are read-only.")
    return t


@router.get("")
async def list_tasks(date: str | None = None, user=Depends(current_user)):
    today = today_for(user)
    day = parse_date(date) if date else today
    docs = await db.tasks.find({"user_id": user["_id"], "date": day.isoformat()}).sort("created_at", 1).to_list(None)
    return {
        "date": day.isoformat(),
        "is_today": day == today,
        "is_past": day < today,
        "tasks": [ser(t) for t in docs],
    }


@router.post("")
async def create_task(body: TaskIn, user=Depends(current_user)):
    doc = {
        "user_id": user["_id"],
        "date": today_for(user).isoformat(),
        "title": body.title.strip(),
        "description": body.description.strip(),
        "image_url": body.image_url,
        "completed": False,
        "completed_at": None,
        "created_at": now(),
    }
    res = await db.tasks.insert_one(doc)
    doc["_id"] = res.inserted_id
    return {"task": ser(doc), "stats": await compute_stats(user["_id"])}


@router.put("/{task_id}")
async def update_task(task_id: str, body: TaskIn, user=Depends(current_user)):
    t = await own_task_today(task_id, user)
    patch = {"title": body.title.strip(), "description": body.description.strip(), "image_url": body.image_url}
    await db.tasks.update_one({"_id": t["_id"]}, {"$set": patch})
    t.update(patch)
    return {"task": ser(t), "stats": await compute_stats(user["_id"])}


@router.post("/{task_id}/toggle")
async def toggle_task(task_id: str, user=Depends(current_user)):
    t = await own_task_today(task_id, user)
    done = not t["completed"]
    await db.tasks.update_one({"_id": t["_id"]}, {"$set": {"completed": done, "completed_at": now() if done else None}})
    await db.users.update_one({"_id": user["_id"]}, {"$inc": {"total_completed": 1 if done else -1}})
    t["completed"] = done
    return {"task": ser(t), "stats": await compute_stats(user["_id"])}


@router.delete("/{task_id}")
async def delete_task(task_id: str, user=Depends(current_user)):
    t = await own_task_today(task_id, user)
    await db.tasks.delete_one({"_id": t["_id"]})
    if t["completed"]:
        await db.users.update_one({"_id": user["_id"]}, {"$inc": {"total_completed": -1}})
    return {"stats": await compute_stats(user["_id"])}
