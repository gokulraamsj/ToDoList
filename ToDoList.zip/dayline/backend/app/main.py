from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from .db import db
from .routes_auth import router as auth_router
from .routes_goals import router as goals_router
from .routes_misc import UPLOAD_DIR, router as misc_router
from .routes_tasks import router as tasks_router


@asynccontextmanager
async def lifespan(_: FastAPI):
    await db.users.create_index("email", unique=True)
    await db.tasks.create_index([("user_id", 1), ("date", 1)])
    await db.goals.create_index("user_id")
    yield


app = FastAPI(title="Dayline API", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

for r in (auth_router, tasks_router, goals_router, misc_router):
    app.include_router(r, prefix="/api")

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIR), name="uploads")
